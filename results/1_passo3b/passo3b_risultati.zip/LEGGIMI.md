# Risultati del passo 3b — tutti gli 80 esercizi (54 di validazione + 26 di sviluppo)

Gemma 4 26B A4B QAT (LM Studio), 6 prompt (zero_shot, static k2, random k3, bm25 k2, bm25 k3, hybrid k3), 3
ripetizioni, 2 formati di uscita (PlantUML, JSON compatto): 2.874 risposte (1.938 sui 54 + 936 sui 26). La cella
static di AirTravel non esiste (AirTravel e' uno dei due esempi fissi).

- `validazione` = i 54 esercizi dell'analisi principale (34 del corpus + 20 De Bari), mai usati per le scelte;
- `sviluppo` = i 26 esercizi su cui e' stata scelta la configurazione (misurando bm25): analisi SECONDARIA, da
  riportare a parte (voce 151).

## Cartelle
- `risposte/puml/<insieme>/<esercizio>/<prompt>_r<rip>.puml`: risposte del formato PlantUML, testo esatto del modello.
- `risposte/json/<insieme>/<esercizio>/<prompt>_r<rip>.puml`: risposte del formato JSON compatto CONVERTITE in
  PlantUML canonico (il diagramma valutato, dopo il post-processing e l'espansione in Apollon). Le poche risposte
  compatte non valide non sono convertibili: restano come `.json`, il testo esatto del modello.
- Le metriche del CSV sono calcolate dopo il post-processing (conversione in Apollon), non su questi file grezzi.
- `gt/<esercizio>.puml`: diagramma di riferimento in PlantUML canonico; `gt/<esercizio>.txt`: traccia dell'esercizio
  (il testo dato al modello).
- `risposte.csv`: una riga per risposta, con le colonne `insieme` (validazione / sviluppo) e `file` (percorso della
  risposta nello zip). `esercizi.csv`: una riga per esercizio, con `insieme`.

## Colonne di risposte.csv
- `esercizio`, `split` (corpus / debari), `formato` (plantuml / compatto), `condizione`, `k`, `condizione_k`,
  `ripetizione` (0-2), `call_id`.
- `livello`: livello di validita' raggiunto (>= 3 = valida; -1 = chiamata fallita o testo non estraibile).
- `V` (1 = valida), `Vc` (1 = valida e senza scarti nel post-processing), `troncata` (1 = limite di 4096 token),
  `scheletro` (1 = valida senza nessun attributo per un GT che ne ha).
- `J`: Jaccard dei nomi di classe con il GT. `R`: relazioni del GT ritrovate con stesse due classi e stesso tipo /
  relazioni del GT. `M1`: estremi del GT con molteplicita' esplicita uguale nella risposta / estremi espliciti del GT
  (vuoto se il GT non ne ha). Metriche congelate (evaluation/metrics.py, voce 127).
- `P_<tipo>_<livello>`, `R_<tipo>_<livello>`, `F1_<tipo>_<livello>`: precision, recall, F1 per tipo di elemento
  (classi, attributi, relazioni strutturali, generalizzazioni) con abbinamento rilassato (`ril`) o esatto (`esa`)
  (evaluation/element_metrics.py, voce 136). Relazioni abbinate per coppia di classi, senza tipo ne' verso.
  `tp_`, `fp_`, `fn_`: i conteggi corrispondenti (per medie micro). Vuoto = non definito (es. P senza elementi).
- Una risposta NON valida conta 0 in J, R e nelle recall / F1 (diagramma vuoto); la sua precision e' vuota.
- `token_output`, `latenza_s`: costo della generazione. `esempi`: id degli esempi nel prompt, nell'ordine;
  `Jt_max_esempi`, `Jt_medio_esempi`: somiglianza (token dei nomi di classe) tra il GT dell'esercizio e quelli degli
  esempi. `file_puml`: percorso del diagramma nello zip.

## Metrica primaria proposta
F1 delle relazioni, abbinamento rilassato (`F1_relazioni_ril`), media per esercizio (da confermare, domanda 11).
